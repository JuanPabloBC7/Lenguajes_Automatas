/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PrimerProyecto;

/**
 *
 * @author juan pablo
 */
public enum Token 
{
    SEPARACION, 
    V_PREDEFINIDAS, 
    P_RESERVADA,
    P_RESERVADA_DB,
    VARIABLE,
    HTML,
    OP_ARITMETICO,
    OP_LOGICOS,
    TI_LOGICO,
    TI_ENTERO,
    TI_REALES,
    CADENA,
    FUNCIONES,
    IF,
    WHILE, 
    FOREACH,
    FOR,
    SWITCH, 
    INCLUDE,
    CONTINUE,
    RETURN,
    INTERVALO,
    ASIGNACION,
    SIGNO,
    COMENTARIO,
    ERROR;    
}
